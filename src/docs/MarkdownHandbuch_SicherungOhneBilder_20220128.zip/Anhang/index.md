# Anhang

Im Anhang dieses Handbuchs findest du Lizenzhinweise und eine Auflistung der Länder mit ihren ISO-Codes.


