# Besuchte Artikel

Unter _**Statistiken \> Verkaufte Artikel \> Besuchte Artikel**_ findest du die meistbesuchten Artikel. Diese werden absteigend nach Anzahl der Besuche aufgelistet. Haben zwei Artikel die gleiche Anzahl Besuche, wird der Artikel mit der kleinsten ID \(älterer Artikel\) vorrangig angezeigt. Unterhalb der Liste befindet sich links die Angabe, welche Artikel aus der Menge der gesamten Artikel angezeigt werden. Rechts kannst du die Seite, die du anzeigen möchtest, über die Pfeil-Symbole << bzw. \>\> oder das Dropdown-Menü auswählen.



