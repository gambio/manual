# Wer ist online?

Unter _**Statistiken \> Wer ist online?**_ kannst du anzeigen, wer derzeit deinen Shop besucht. Dabei werden folgende Informationen aufgelistet:

-   online \(im Shop verbrachte Zeit\)
-   id
-   name
-   ip-Adresse
-   Startzeit
-   letzter Klick
-   Warenkorb

sowie die letzte, aufgerufene URL. Unterhalb der Tabelle wird die Anzahl der derzeitigen Kunden angezeigt.

!!! note "Hinweis" 
	 Bei Kunden, die sich nicht im Shop angemeldet haben, wird als Name _**Guest**_ und als ID 0 ausgegeben.



