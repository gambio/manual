# Statistiken

Die Statistiken geben u.a. Auskunft über die Anzahl der Besucher. die von ihnen aufgerufenen Seiten sowie die im Shop gemachten Umsätze.




