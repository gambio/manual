# Lokalisierung

Im nachfolgenden Kapitel findest du Informationen zur Konfiguration der Steuern, Sprachen und Lieferzonen.

!!! danger "Achtung"

	 Nimm Änderungen an den nachfolgenden Einstellungen nur vor, wenn du genau weißt, was du tust und welche Auswirkungen deine Änderungen auf das Shopsystem haben. Fehlerhafte Änderungen an den Sprach- und Umsatzsteueroptionen können dazu führen, dass dein Shop nicht mehr funktioniert.




