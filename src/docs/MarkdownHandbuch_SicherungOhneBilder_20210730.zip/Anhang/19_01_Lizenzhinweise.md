# Lizenzhinweise

Bitte beachte nachfolgende Lizenzhinweise zum Shopsystem, dem PdfCreator sowie dem Handbuch.

## Shopsystem

Das Shopsystem steht unter der GNU General Public License Version 2 \(GPL\). Eine Kopie der Lizenz findest du auf unserer Internetseite unter:

_**http://www.gambio.de/hinweise/gpl.html**_

Eine deutsche Übersetzung der Lizenz findest du unter:

_**http://www.gambio.de/hinweise/gplgerman.html**_

## PdfCreator

Der PdfCreator ist ein eigenständiges Modul und steht nicht unter der GNU GPL Lizenz. Eine Kopier der Lizenz zum PdfCreator findest du auf unserer Internetseite unter:

_**http://www.gambio.de/hinweise/pdfcreator.html**_

## Handbuch

Das vorliegende Handbuch \(das Handbuch\) ist nicht Teil des Shopsystems und steht nicht unter der GNU GPL Lizenz. Das Urheberrecht für das Handbuch liegt bei der Gambio GmbH. Die Weitergabe und Verfielfältigung des Handbuchs oder Auszügen daraus ist ausschließlich mit schriftlicher Genehmigung der Gambio GmbH gestattet.

