# Verkaufte Artikel

Unter _**Statistiken \> Verkaufte Artikel \> Verkaufte Artikel**_ werden die meistverkauften Artikel aufgelistet. Wie schon bei den besuchten Artikeln gilt, dass zwei Artikel mit der gleichen Anzahl an Aufrufen gemäß der ID ausgegeben werden. Es wird also der ältere Artikel \(mit der kleineren ID\) vorrangig angezeigt.

Hat der Kunde die Bestseller-Box aktiviert, so werden darin die Artikel aus dieser Statistik angezeigt. Diese Box wird über den Bereich _**Menübox-Positionen**_ im StyleEdit \(siehe Kapitel _**Template-Einstellungen**_\) aktiviert.

Unter _**Statistiken \> Statistiken löschen**_ kann diese Statistik gezielt gelöscht werden.


