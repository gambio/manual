# Gutscheine und Rabatt Coupons {#gutscheine_und_rabatt_kupons}

!!! note "Hinweis" 
	 Wenn du Gutscheine oder die Rabatt Coupons verwenden möchtest, installiere zuerst das Modul _**Gutscheinsystem**_ unter _**Module \> Modul-Center**_.



