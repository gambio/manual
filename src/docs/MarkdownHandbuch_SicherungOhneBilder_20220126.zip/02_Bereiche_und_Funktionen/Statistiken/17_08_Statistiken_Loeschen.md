# Statistiken löschen

Über den Menüpunkt _**Statistiken \> Statistiken löschen**_ können bei Bedarf die shopeigenen Statistiken geleert werden. Dies kann z.B. dann sinnvoll sein, wenn auf Basis einer bestehenden Shopdatenbank ein neuer Shop erstellt worden ist.

Setze die Haken für die gewünschte\(n\) Statisik\(en\) und bestätige mit Klick auf den Button _**Löschen**_.