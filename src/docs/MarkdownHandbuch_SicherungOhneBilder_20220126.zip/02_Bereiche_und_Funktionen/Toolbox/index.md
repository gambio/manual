# Toolbox

Der Bereich _**Toolbox**_ umfasst unterschiedliche Bestandteile des Shops, die hauptsächich interne Verwaltungsaufgaben wahrnehmen. Hierzu gehöhen u.a. die verschiedenen Caches (Zwischenspeicher), das Anlegen von Sicherungen (nur in selbstgehosteten Shops), Anzeige von Serverinformationen, aber auch Versand und Verwaltung von Newslettern.


