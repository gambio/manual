# Gutscheine und Rabatt Kupons {#gutscheine_und_rabatt_kupons}

!!! note "Hinweis" 
	 Wenn du Gutscheine oder die Rabatt Kupons verwenden möchtest, installiere zuerst das Modul _**Gutscheinsystem**_ unter _**Module \> Modul-Center**_.



