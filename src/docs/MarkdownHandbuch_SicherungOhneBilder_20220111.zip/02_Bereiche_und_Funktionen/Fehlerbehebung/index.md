# Fehlerbehebung

Dieses Kapitel beschreibt die notwendigen Schritte zum Anlegen einer vollständigen Sicherung des Shops (Dateien und Datenbank) sowie das allgemeine Vorgehen zum Zurückspielen eines Backups.


