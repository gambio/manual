# Konfiguration

Dieses Kapitel beschreibt die Grundkonfiguration deines neuen Onlineshops.