# Zusatzfunktionen

## Cross Selling

Cross Selling ist eine Marketing-Funktion, mit der du einem Artikel weitere Artikel als Empfehlung hinzufügst. Die Empfehlungen werden im Shopbereich unterhalb der Artikelbeschreibung angezeigt.

![](../Bilder/ArtikelUNDKategorien_Zusatzfunktionen_CrossSelling_CrossSellingArtikelverknuepfung.png "Cross Selling (Artikelverknüpfung)")

### Artikelempfehlung hinzufügen

1.  Markiere den Artikel, zu dem du Empfehlungen hinzufügen möchtest
2.  Klicke auf _**Cross Selling**_
3.  Trage im Feld _**Produktsuche**_ eine Artikelnummer oder einen Artikelnamen ein, den du zum gewählten Artikel empfehlen möchtest und klicke auf _**Suchen**_
4.  Aktiviere das Kontrollkästchen in der Spalte _**Hinzufügen**_ bei den gefundenen Artikeln, die du zum gewählten Artikel empfehlen möchtest
5.  Klicke auf _**Speichern**_

### Artikelempfehlung löschen

1.  Markiere den Artikel, aus dem du Empfehlungen löschen möchtest
2.  Klicke in der rechten Spalte auf _**Cross Selling**_
3.  Aktiviere das Kontrollkästchen in der Spalte _**Löschen**_ bei den Empfehlungen, die du löschen möchtest
4.  Klicke auf _**Speichern**_ und bestätige das Speichern der Änderungen mit _**OK**_

### Automatische Rückverknüpfung

Artikelempfehlungen werden in der Grundeinstellung des Shopsystems automatisch in beide Richtungen verknüpft. Im empfohlenen Artikel wird der ursprüngliche Artikel auf der Artikel-Detailseite unter _**Dieses Produkt ist kompatibel zu**_ angezeigt. Die automatische Rückverknüpfung kannst du im Gambio Admin deines Shops unter _**Einstellungen / Layout / Design / Artikeldetailseite**_ deaktivieren. Ändere die Option bei _**Reverse Cross-Marketing**_ auf ✖ und speichere die Änderung.

![](../Bilder/ArtikelUNDKategorien_Zusatzfunktionen_CrossSelling_AutomatischeRueckverknuepfungAktivieren.png "Automatische Rückverknüpfung aktivieren")

Wenn du die automatische Rückverknüpfung deaktiviert hast und die Funktion reaktivieren möchtest, ändere die Option bei _**Reverse Cross-Marketing**_ auf ✔ und speichere die Änderung.

## Cross-Marketing Gruppen

Mit Hilfe von Cross-Marketing Gruppen können Cross Selling Artikel mit einem Gruppen-Bezeichner versehen werden.

!!! note "Hinweis"

	 Cross-Marketing Gruppen sind rein optische Textauszeichnungen. Es ist z.B. standardmäßig nicht möglich, Gruppen von Cross Selling Artikeln einem anderen Artikel zuzuordnen.

### Cross-Marketing Gruppe anlegen

Um eine Cross-Marketing-Gruppe anzulegen, gehe im Gambio Admin unter _**Artikel \> Cross-Marketing Gruppen**_ und klicke auf die grüne Schaltfläche _**Erstellen**_.

![](../Bilder/ArtikelUNDKategorien_Zusatzfunktionen_CrossMarketingGruppen_SchaltflaecheErstellenInDerUebersichtDerCrossMarketingGruppen.png "Schaltfläche _**Erstellen**_ in der Übersicht der
        Cross-Marketing Gruppen")

Du kannst den Gruppennamen jeweils pro im Shop vorhandener Sprache eintragen.

![](../Bilder/ArtikelUNDKategorien_Zusatzfunktionen_CrossMarketingGruppen_EingabemaskenFuerDasAnlegenVonCrossMarketingGruppen.png "Eingabemaske für das Anlegen von Cross-Marketing
        Gruppen")

Bestätige die Eingabe mit einem Klick auf _**Einfügen**_. Über _**Abbrechen**_ kannst du die Eingabemaske wieder verlassen, ohne die Eingabe zu übernehmen.

### Cross-Marketing Gruppe bearbeiten

Um eine Cross-Marketing Gruppe zu bearbeiten, wähle diese unter _**Artikel \> Cross-Marketing Gruppen**_ aus und klicke auf die Schaltfläche _**Bearbeiten**_, in der rechten, unteren Bildschirmecke. Klicke auf _**Aktualisieren**_. um die Änderungen zu übernehmen. Über _**Abbrechen**_ verlässt du die Eingabemaske wieder, ohne die Eingaben zu speichern.

### Cross-Marketing Gruppe löschen

Um eine Cross-Marketing Gruppe zu löschen, wähle diese unter _**Artikel \> Cross-Marketing Gruppen**_ aus und klicke auf die Schalftlfäche _**Löschen**_ in der rechten, unteren Bildschirmecke. Bestätige die Sicherheitsabfrage mit einem erneuten Klick auf _**Löschen**_, um die Cross-Marketing Gruppe zu entfernen. Über _**Abbrechen**_ verlässt du den Dialog, ohne die Gruppe zu löschen.

### Cross-Marketing Gruppe einstellen

Cross-Marketing Gruppen können nach dem Hinzufügen, beziehungsweise beim Bearbeiten, von Cross Selling Artikeln eingestellt werden.

![](../Bilder/ArtikelUNDKategorien_Zusatzfunktionen_CrossMarketingGruppen_EinstellungDerCrossMarketingGruppeBeiEinemTestartikel.png "Einstellunge der Cross-Marketing Gruppe bei einem
        Testartikel")

Wähle hierzu den gewünschten Eintrag aus dem Dropdownmenü _**Gruppe**_ aus, setze ggf. den Haken für _**hinzufügen**_ und bestätige mit _**Speichern**_ respektive Aktualisieren.

## Downloadartikel

!!! danger "Achtung"

	 Downloadartikel setzen die Verwendung des Attribut-Systems voraus. Es sollte daher sichergestellt werden dass unter _**Module \> Modul-Center**_ das Modul _**Artikelattribute**_ installiert ist.

Das Erstellen von Download-Artikeln wird im Shop über das Attribut-System ermöglicht. Gehe zunächst unter _**Artikel \> Artikelattribute**_, hier sollte das Attribut _**downloads**_ vorhanden sein. Ist dies nicht der Fall, lege es bitte an. Gehe hierzu wie folgt vor:

In der oberen Tabelle findest du die Spalte _**Artikelmerkmal-Bezeichnung**_. Scrolle bis zum unteren Ende, hier findest du die Eingabefelder _**de:**_ und _**en:**_. Trage unter _**de:**_ den Begriff _**downloads**_ ein, achte hierbei bitte auf die Kleinschreibung und das s am Ende. Klicke auf _**Einfügen**_ um das Attribut hinzuzufügen.

Im zweiten Schritt scrolle bitte an das Ende der Tabelle _**Optionswerte**_. Wähle im Dropdown der Spalte _**Artikelmerkmal-Bezeichnung**_ das Attribut _**downloads**_ aus und trage im Feld _**de:**_ eine Beschreibung ein, z.B. _**PDF-Download**_ oder dergleichen. Klicke auf _**Einfügen**_ um den Optionswert hinzuzufügen.

Beim Anlegen des zugehörigen Artikels unter _**Artikel \> Artikel/Kategorien**_ gibt es nur wenige Unterschiede zu einem physischen Artikel. Zum Einen sollte die Einstellung _**Artikeltyp**_ im Bereich _**Erweiterte Konfiguration**_ von _**Standard**_ auf _**Download**_ geändert werden. Zum Anderen ist es vorgesehen, unter _**Preisoptionen**_ die Einstellung _**Steuerklasse**_ von _**Standard**_ auf _**elektronisch erbrachte Leistung**_ zu setzen.

!!! danger "Achtung"

	 Bitte beachte, dass wir dir hinsichtlich der Steuer-Einstellungen nur die gängigen Voreinstellungen nennen können, die für die meisten Shopbetreiber anwendbar sind. Wie du für deinen individuellen Shop verfahren musst und ob es hierbei Besonderheiten gibt, die berücksichtigt werden müssen, erfrage bitte bei deinem Steuerberater oder Rechtsbeistand.

Um die Datei im Shop zur Verfügung stellen zu können, muss sie auf den FTP-Server hochgeladen werden. Verbinde dich hierzu mit deinem FTP-Server und wechsele in dein Shop-Verzeichnis. Lade die Datei in den Ordner _**download**_ hoch.

Um den Download-Artikel einzurichten, muss das passende Attribut zugeordnet werden. Wähle hierzu den Artikel unter _**Artikel \> Artikel/Kategorien**_ aus und wähle _**Attribute editieren**_ über die Dropdown-Schaltfläche oder verwende die Auswahl unter _**Artikel \> Artikelattribute \> Attributverwaltung**_. Du siehst eine Auflistung aller Attribute, die dem Artikel zugeordnet werden können. Ein Aufruf ist auch direkt aus de Artikelmaske, über den Dropdown-Button _**Attribute**_ möglich.

Setze den Haken bei der von dir gewählten Bezeichnung, in unserem Beispiel also bei _**PDF-Download**_. Die vorher ausgegrauten Eingabefelder zur Einrichtung von Attributen werden nun angezeigt. Unterhalb dieser Zeile finden sich zudem Einstellungen, die nur für Download-Artikel zur Verfügung stehen.

![](../Bilder/ArtikelUNDKategorien_Zusatzfunktionen_Downloadartikel_ArtikeldownloadHinzufuegen.png "Artikeldownload hinzufügen")

Trage im Feld _**Lager**_ einen fiktiven Lagerstand ein, dieser wird benötigt, damit der Artikel heruntergeladen werden kann. Wenn du andere Attribute verwendest und den Lagerstand abziehst, sollte der Wert entsprechend hoch gewählt werden.

Im Dropdown-Menü unterhalb des Namens _**PDF-Download**_ kannst du die vorher hochgeladene Datei auswählen.

!!! note "Hinweis" 
	 Wenn die Datei nicht angezeigt wird, kann ein Problem mit dem Dateinamen vorliegen. Prüfe in diesem Fall, ob dieser Umlaute oder Sonderzeichen enthält und ändere diese entsprechend ab.

Unter _**Mögl. Downloads**_ wird hinterlegt, wie oft die Datei von einem Kunden heruntergeladen werden kann. Unter _**Downloadzeit \(Tage\)**_ wird festgelegt, wie lange der Download-Link für den jeweiligen Kunden gültig ist. Beide Einträge müssen vorgenommen werden und größer als 0 sein, damit die Datei vom Kunden heruntergeladen werden kann.

!!! note "Hinweis"
	 Bei bereits abgeschlossenen Bestellungen ist eine nachträgliche Änderung der möglichen Downloads oder der Downloadzeit nicht vorgesehen. Beide werden zusammen mit der Bestellung gespeichert und bei einer Anpassung innerhalb der Optionswerte nicht aktualisiert. 

Der Download-Link wird für den Kunden verfügbar, sodass er den Artikel in seinem Konto herunterladen kann, wenn ein bestimmter Bestellstatus erreicht wurde. Diesen kannst du selber unter _**Einstellungen / Artikel & Kategorien / Downloadoptionen**_ im Bereich _**Download-Bestellstatus**_ festlegen. Du kannst wahlweise einen \(oder mehrere\) bestehende\(n\) Bestellstatus verwenden oder einen neuen Status \(z.B. _**Download erlaubt**_\) unter _**Bestellungen \> Bestellstatus**_ zu diesem Zweck anlegen.

!!! note "Hinweis" 
	 Über die Einstellung _**Download Zahlungsmodule**_ unter _**Einstellungen / Artikel & Kategorien / Downloadoptionen**_ kannst du festlegen, welche Zahlungsweisen bei Download-Artikeln nicht verwendet werden dürfen. Standardmäßig sind hier die Module _**banktransfer**_, _**cod**_, _**invoice**_ und _**moneyorder**_ eingetragen.

!!! danger "Achtung"

	 Die Einstellung _**Download durch Weiterleitung**_ ist standardmäßig abgeschaltet. Sie sollte nur verwendet werden, wenn dies unbedingt erforderlich ist.

Setze die Einstellungen im Bereich _**Download-Bestellstatus**_ unter _**Einstellungen / Artikel & Kategorien / Downloadoptionen**_ für die Bestellstatus, mit denen du einen Download ermöglichen möchtest. Wenn du den Status der Bestellung änderst, z.B. nach einem bestätigen Zahlungseingang, kannst du deinen Kunden über die Benachrichtigungsfunktion innerhalb der Bestellung \(_**Bestellstatus ändern**_, Haken setzen für _**Kunde benachrichtigen**_ und _**Kommentare mitsenden**_\) darüber informieren, dass der Download nun zur Verfügung steht.

Bei Zahlung per Zahlungsweisen mit sofortiger Transaktionsbestätigung wie PayPal oder Sofortüberweisung, kann der Kunde den Artikel direkt nach Abschluss der Bestellung herunterladen. Achte hierbei darauf, dass der betreffende Status unter _**Einstellungen / Artikel & Kategorien / Downloadoptionen**_ aktiviert ist.

Bei Zahlung per PayPal kannst du unter _**Module \> Zahlungsweisen \> PayPal**_ und _**PayPal Plus \> Konfiguration \> Experteneinstellungen**_ unter _**Bestellstatusänderungen nach Aktionen**_ einen Bestellstatus auswählen, der nach erfolgreicher Bestellung automatisch zugewiesen wird. Wenn du einen eigenen Status verwendest kann dieser hier eingestellt werden \(z.B. _**Download erlaubt**_\). Nach erfolgreicher Bestellung mit Zahlung über PayPal wird im Konto des Kunden der Downloadlink zum Herunterladen der hinterlegten Datei freigeschaltet.

## Artikel-Filter

### Einleitung

!!! abstract "Definitionen"

	 Es werden die folgenden Begriffe verwendet:
	 
	 - _**Filterauswahl**_:
	 	- beschreibt ein grundlegendes Merkmal, nach dem gefiltert werden kann, wie _Größe_, _Farbe_, _Länge_, _Ausstattung_ usw. 
	 - _**Filterwerte**_ und _**Auswahlwerte**_: 
	 	- beschreiben die tatsächliche Ausprägung des betreffenden Merkmals, wie _XL_, _blau_, _110 cm_, _Klimaanlage_ usw.
	 	- sind Bestandteil einer Filterauswahl
	 - _**Filter-Set**_: 
	 	- beschreibt eine Kombination von Filterwerten, meist aus verschiedenen Filterauswahlen, die einem Artikel zugewiesen sind
	 	- Artikeln können mehrere Filter-Sets zugewiesen werden, die untereinander unabhängig sind, um verschiedene Varianten des Artikels abzubilden, z.B. Texttilien, bei denen bestimmte Größen nicht in allen Farben angeboten werden
	 - _**Filter**_: 
	 	- beschreibt die Zuordnung von Filterauswahlen zu einer Seite, auf der Besucher nach Merkmalen filtern können
	 	- können sowohl auf der Startseite als auch auf Kategorieseiten angelegt werden

Über Filter können Artikel unabhängig von Kategorien oder Suchbegriffen im Shop gefunden und aufgelistet werden. Hierzu werden den Artikeln sogenannte _**Filtewerte**_ bzw. _**Auswahlwerte**_ zugeordnet. Zusammengehörige Filterwerte sind Teil einer _**Filterauswahl**_. Ein oder mehrere Filterauswahlen können zu einem _**Filter**_, wie z.B. dem Startseitenfilter oder dem Kategoriefilter, zusammengestellt werden. Die Kombination von Filterwerten innerhalb eines Artikels wird als _**Filter-Set**_ bezeichnet.

!!! example "Beispiel"

	 Du verkaufst Kleidung in verschiedenen Größen (S, M, L, XL) und Farben (rot, grün, blau). _Größe_ und _Farbe_ sind mögliche _**Filterauswahlen**_, _S_, _M_, _L_ und _XL_ bzw. _rot_, _grün_ und _blau_ entsprechend mögliche _**Auswahlwerte**_. 

	 ![](../../Bilder/artikelfilter/FilterSetAuswahlBeispiel.png "Filterauswahl _**Farbe**_ und Auswahlwerte _**rot**_, _**grün**_ und _**blau**_")

	 Du bietest einen Artikel in zwei verschiedenen Varianten an. Die Variante in der _**Farbe**_ _blau_ wird in den _**Größen**_ _M_ und _S_; die Variante in der _**Farbe**_ _rot_ in den _**Größen**_ _L_ und _XL_ angeboten.

	 ![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_maskeFilterauswahl_.png "eingerichtete _**Filter-Sets**_ in einem Artikel")

	 Die Filterauswahlen _**Farbe**_ und _**Größe**_ sind z.B. in einem Kategoriefilter enthalten.

	 ![](../../Bilder/artikelfilter/artikelfilter_Filterbox_.png "Menübox für Artikel-Filter")

	 Zusätzlich zu den Auswahlwerten kann nach dem Artikelpreis gefiltert werden.


### Beschreibung der Masken zur Einrichtung von Artikel-Filtern

#### Masken unter Artikel > Artikel-Filter

##### Filterauswahl (neu) 

![](../../Bilder/artikelfilter/artikelfilter_artikelartikelfilter_maskeFilterauswahlNeu.png "Eingabemaske _**Filterauswahl (neu)**_ unter _**Artikel > Artikel-Filter**_ ")

| Feldname                | Beschreibung                                                 |
| ----------------------- | ------------------------------------------------------------ |
| _**alle Sprachen**_     | blendet Eingabefelder für alle im Shop eingerichteten Sprachen ein |
| _**aktuelle Sprache**_ | blendet nur das Eingabefeld für die aktuell im Gambio Admin verwendete Sprache  ein |
| **[Landesflagge]**      | Name der Filterauswahl                                       |
| _**Anlegen**_           | erstellt eine Filterauswahl mit dem eingegebenen Namen       |



##### Filter Einstellungen 

![](../../Bilder/artikelfilter/artikelfilter_artikelartikelfilter_maskeFilterEinstellungen.png "Eingabemaske _**Filter Einstellungen**_ unter _**Artikel > Artikel-Filter**_ ")

| Feldname                        | Beschreibung                                                 |
| ------------------------------- | ------------------------------------------------------------ |
| _**Filterdeaktivierung**_       | wie soll mit Filterauswahlen verfahren werden, bei denen durch eine vorherige Auswahl von Filtewerten selbst keine Werte mehr auswählbar sind? |
|                                 | _**ausblenden**_: Filterauswahl wird ausgeblendet            |
|                                 | _**anzeigen**_: es wird die Meldung _**Es wurden keine passenden Filterwerte gefunden.**_ angezeigt. |
| _**"Preis von"-Feld anzeigen**_ | ist der Haken gesetzt, wird das Feld _**Preis von**_ des standardmäßigen Preisfilters angezeigt |
| _**"Preis bis"-Feld anzeigen**_ | ist der Haken gesetzt, wird das Feld _**Preis bis**_ des standardmäßigen Preisfilters angezeigt |
| _**Speichern**_                 | speichert die in der Maske vorgenommenen Einstellungen       |



##### Filterauswahl (eingerichtete) 

![](../../Bilder/artikelfilter/artikelfilter_artikelartikelfilter_maskeFilterauswahlEingerichtete.png "Eingabemaske _**Filterauswahl (eingerichtete)**_ unter _**Artikel > Artikel-Filter**_ ")

Ein Klick auf den Namen der Filterauswahl öffnet die Maske _**Auswahlwerte**_ für die jeweilige Filterauswahl.

##### Auswahlwerte

![](../../Bilder/artikelfilter/artikelfilter_artikelartikelfilter_maskeAuswahlwerte.png "Maske _**Auswahlwerte**_ nach Anklicken einer eingerichteten Filterauswahl")

| Feldname / Filterauswahlname (gewählt) | Beschreibung                                              |
| -------------------------------------- | --------------------------------------------------------- |
| **[Landesflagge]**                     | Name der Filterauswahl                                    |
| _**löschen**_                          | löscht die gesamte Filterauswahl                          |
| _**interner Name**_                    | Name der Filterauswahl für die Verwendung im Gambio Admin |

| Feldbname / Neuer Auswahlwert | Beschreibung                                                 |
| ----------------------------- | ------------------------------------------------------------ |
| **[Landesflagge]**            | Name des neuen Auswahlwertes                                  |
| _**Speichern**_               | speichert die Änderungen in dieser und der darüberstehenden Maske |

| Feldname / Auswahlwerte (eingerichtet) | Beschreibung                                       |
| -------------------------------------- | -------------------------------------------------- |
| **[Landesflagge]**                     | Name des jeweiligen Auswahlwertes                    |
| **[Sortierung]**                       | Reihenfolge des Auswahlwertes in der Filterauswahl |
| _**löschen**_                          | löscht den jeweiligen Auswahlwert                  |
| _**Speichern**_                        | speichert die Änderungen in dieser Maske           |





##### Filterauswahl Startseite 

![](../../Bilder/artikelfilter/artikelfilter_artikelartikelfilter_maskeFilterauswahlStartseite.png "Eingabemaske _**Filterauswahl Startseite**_ unter _**Artikel > Artikel-Filter**_ ")

| Feldname                             | Beschreibung                                                 |
| ------------------------------------ | ------------------------------------------------------------ |
| _**Aktivieren**_                     | ist der Haken gesetzt, wird der Startseitenfilter angezeigt  |
| _**Hinzufügen**_                     | fügt die im nebenstehenden Dropdown eingestellte Filterauswahl dem Startseitenfilter hinzu |
| _**Auswahlmodus**_                   | auf welche Weise sollen Filterwerte ausgewählt werden können?     |
|                                      | _**Standard**_: alle Filterauswahlen werden zu Anfang angezeigt |
|                                      | _**Stufenweise**_: nur die erste Filterauswahl in der Sortierung wird zu Anfang angezeigt, erst nach der Auswahl eines Filterwerts erscheint die in der Sortierung nächste Filterauswahl |
| _**Filterwertdeaktivierung**_        | wie soll mit Filterwerten verfahren werden, die durch eine vorherige Auswahl selbst nicht mehr wählbar sind? |
|                                      | _**ausblenden**_: nicht mehr wählbare Filterwerte werden ausgeblendet |
|                                      | _**deaktivieren**_: nicht mehr wählbare Filterwerte werden ausgegraut |
| _**Globaler Startseitenfilter**_     | ist der Haken gesetzt, wird der Startseitenfilter auch in Kategorien angezeigt, bei denen kein eigener Kategoriefilter aktiviert ist |
| _**Persistenter Startseitenfilter**_ | ist der Haken gesetzt, werden die im Startseitenfilter vorgenommenen Einstellungen weitestmöglich auch für andere Seiten übernommen |
| _**AND**_                            | ist der Haken gesetzt, wird die jeweilige Filterauswahl UND-verknüpft |

!!! danger "Achtung"

	 Das Deaktivieren des globalen Startseitenfilters schaltet nicht gleichzeitig den persistenten Startseitenfilter ab. Ist der Haken für _**Persistenter Startseitenfilter**_ gesetzt, kann dies auch ohne aktivierten Startseitenfilter Auswirkungen auf die Filter des Shops haben.

!!! note "Hinweis"
	 Sind die Filterauswahlen UND-verknüpft, besteht eine Abhängigkeit zwischen den Filterwerten. D.h. es lässt sich nur gleichzeitig nach Farbe rot und Größe M filtern, wenn es mindestens einen Artikel gibt, dem diese Auswahlwerte zugeordnet sind.

| Feldname         | Beschreibung                                                 |
| ---------------- | ------------------------------------------------------------ |
| _**Sortierung**_ | legt die Reihenfolge der Filterauswahl im Filter fest        |
| _**Vorlage**_    | wie soll die Filterauswahl angezeigt werden?                 |
|                  | _**dropdown.html**_: ![](../../Bilder/artikelfilter/artikelfilter_vorlageDropdown.png "Anzeige als Dropdown") |
|                  | _**checkboxes.html**_: ![](../../Bilder/artikelfilter/artikelfilter_vorlageCheckboxes.png "Anzeige als Checkboxen") |
|                  | _**link_list.html**_: ![](../../Bilder/artikelfilter/artikelfilter_vorlageLinkList.png "Anzeige als Link Liste") |
|                  | _**multiselect.html**_: Vorlage wird nicht mehr verwendet und voraussichtlich in einer zukünftigen Version entfernt |
| _**Löschen**_    | ist der Haken gesetzt, wird die Filterauswahl beim Speichern aus dem Filter entfernt |
| _**Speichern**_ | speichert die vorgenommenen Einstellungen                    |




#### Masken beim Bearbeiten von Kategorien

![](../../Bilder/artikelfilter/artikelfilter_maskeKategorie_Kategoriefilter.png "Eingabemaske _**Kategorie-Filter**_ beim Bearbeiten einer Kategorie")

![](../../Bilder/artikelfilter/artikelfilter_maskeKategorie_KategoriefilterAusgewaehlt.png "Hinzufügen der Filterauswahl über das Dropdown der Kategoriemaske")

![](../../Bilder/artikelfilter/artikelfilter_maskeKategorie_KategoriefilterHinzugefuegt.png "Filterauswahlen nach dem Hinzufügen")

| Feldname                        | Beschreibung                                                 |
| ------------------------------- | ------------------------------------------------------------ |
| _**Kategorie-Filter anzeigen**_ | ist der Haken gesetzt, wird der Kategoriefilter angezeigt    |
| _**Auswahlmodus**_             | auf welche Weise sollen Filterwerte ausgewählt werden? |
|                                 | _**Standard**_: alle Filterauswahlen werden zu Anfang angezeigt |
|                                 | _**Stufenweise**_: nur eine Filterauswahl wird zu Anfang angezeigt, erst nach der Auswahl eines Filterwerts erscheint eine weitere Filterauswahl|
| _**Filterwertdeaktivierung**_ | wie soll mit Filterwerten verfahren werden, die durch eine vorherige Auswahl selbst nicht mehr wählbar sind? |
|                                      | _**ausblenden**_: nicht mehr wählbare Filterwerte werden ausgeblendet |
|                                      | _**deaktivieren**_: nicht mehr wählbare Filterwerte werden ausgegraut |
| _**Name (Interner Name)**_     | Name des Filters in der Auswahl, der interne Name wird im Shop nicht angezeigt |
| _**AND**_                      | ist der Haken gesetzt, wird der jeweilige Filter UND-verknüpft |

!!! note "Hinweis"
	 Sind die Filterauswahlen UND-verknüpft, besteht eine Abhängigkeit zwischen den Filterwerten. D.h. es lässt sich nur gleichzeitig nach Farbe rot und Größe M filtern, wenn es mindestens einen Artikel gibt, dem diese Auswahlwerte zugeordnet sind.

| Feldname         | Beschreibung                                                 |
| ---------------- | ------------------------------------------------------------ |
| _**Sortierreihenfolge**_       | legt die Reihenfolge der Filterauswahl im Kategoriefilter fest |
| _**Vorlage**_                  | wie soll die Filterauswahl angezeigt werden? |
|                  | _**dropdown.html**_: ![](../../Bilder/artikelfilter/artikelfilter_vorlageDropdown.png "Anzeige als Dropdown") |
|                  | _**checkboxes.html**_: ![](../../Bilder/artikelfilter/artikelfilter_vorlageCheckboxes.png "Anzeige als Checkboxen") |
|                  | _**link_list.html**_: ![](../../Bilder/artikelfilter/artikelfilter_vorlageLinkList.png "Anzeige als Link Liste") |
|                  | _**multiselect.html**_: Vorlage wird nicht mehr verwendet und voraussichtlich in einer zukünftigen Version entfernt |
| _**Löschen**_ | ist der Haken gesetzt, wird die Filterauswahl beim Speichern aus dem Kategoriefilter entfernt |
| _**Hinzufügen**_ | die im Dropdown ausgewählte Filterauswahl wird dem Kategoriefilter hinzugefügt |
| _**Speichern**_ | speichert die vorgenommenen Einstellungen ab |

#### Masken beim Bearbeiten von Artikeln

##### Filterauswahl

![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_maskeFilterauswahl.png "Bereich _**Filterauswahl**_ in der Artikelmaske")

| Feldname                                                     | Beschreibung                          |
| ------------------------------------------------------------ | ------------------------------------- |
| **[bearbeiten]** ![](../../Bilder/artikelfilter/icon_bearbeiten.png) | Bearbeiten des Filter-Sets            |
| **[löschen]** ![](../../Bilder/artikelfilter/icon_loeschen.png)  | Löschen des Filter-Sets               |
| _**Hinzufügen**_                                             | Hinzufügen eines weiteren Filter-Sets |

###### Filter-Set bearbeiten

![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_maskeSetBearbeiten.png "Dialog zum Bearbeiten eines Filter-Sets")

| Feldname                            | Beschreibung                                                 |
| ----------------------------------- | ------------------------------------------------------------ |
| _**-- Neuen Filter hinzufügen --**_ | Dropdown zur Auswahl einer zusätzlichen Filterauswahl, die hinzugefügt werden soll |
| _**Abbrechen**_                     | schließt den Dialog, ohne vorgenommene Änderungen zu speichern |
| _**Speichern**_                     | speichert die Änderungen, ohne den Dialog zu schließen       |
| _**Speichern & Schließen**_         | speichert die Änderungnen und schließt den Dialog             |

###### Filter-Set löschen

![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_maskeSetLoeschen.png "Dialog zum Löschen eines Filter-Sets")

| Feldname        | Beschreibung                         |
| --------------- | ------------------------------------ |
| _**Abbrechen**_ | Dialog schließen ohne Set zu löschen |
| _**Löschen**_   | Filter-Set endgültig löschen         |



### Erstellen und Zuordnen von Artikel-Filtern

Damit im Shop nach Artikeln gefiltert werden kann, sind drei wesentliche Einrichtungsschritte notwendig:

- Filterauswahlen mit Auswahlwerten anlegen
- Auswahlwerte den Artikeln in Form von Filter-Sets zuordnen
- Für die Startseite und/oder Kategorien Filter aus Filterauswahlen erstellen

#### Anlegen von Filterauswahlen

![](../../Bilder/artikelfilter/artikelfilter_maskeArtikelArtikelfilter_FilterauswahlNeu.png "_**Artikelfilter (neu)**_ zum Anlegen von Filterauswahlen")

Im Bereich _**Filterauswahl (neu)**_ können neue Filterauswahlen angelegt werden. Über die Links _**alle Sprachen**_ bzw. _**aktuelle Sprache**_ können die Eingabefelder für die verschiedenen Sprachen des Shops ein- bzw. ausgeblendet werden. Trage den Namen der Filterauswahl ein und bestätige mit einem Klick auf _**Speichern**_.

!!! note "Hinweis"
	 Die Links _**alle Sprachen**_ bzw. _**aktuelle Sprache**_ schalten die Eingabefelder für alle Bereiche der Eingabemaske unter _**Artikel > Artikel-Filter**_ an bzw. aus.

Gehe wie folgt vor:

!!! check "Anlegen von Filterauswahlen"
	 1. wenn du mehrere Sprachen verwendest, klicke auf _**alle Sprachen**_
	 2. trage neben die Landesflagge(n) den/die Namen der Filterauswahl ein, wie du ihn/sie im Shop anzeigen möchtest
	 3. klicke auf _**Anlegen**_.

#### Anlegen von Auswahlwerten

![](../../Bilder/artikelfilter/artikelfilter_maskeFilterauswahl_FarbeAusgewaehlt.png "Filterauswahl _**Farbe**_ unter _**Filterauswahl (eingerichtete)**_ ausgewählt")

Unter _**Filterauswahl (eingerichtete)**_ stehen die angelegten Filterauswahlen zur Verfügung. Wähle eine Filterauswahl aus, um Auswahlwerte hierfür zu erstellen. Unter _**Auswahlwerte**_ kann im Feld _**Neuer Auswahlwert**_ der Name des Filterwerts eingetragen werden. Direkt hinter dem Namensfeld kann eine Zahl für die Sortierung des Filterwerts eingetragen werden.

Zudem kann für die Filterauswahl ein _**interner Name**_ eingetragen werden.

!!! example "Beispiel"

	 Du verkaufst in deinem Shop Bekleidung und Schuhe, möchtest aber dass deine Kunden in beiden Fällen nach _**Größe**_ filtern können. Du legst also eine Filterauswahl _**Größe**_ mit internem Namen _**Konfektionsgröße**_ und eine Filterauswahl _**Größe**_ mit internem Namen _**Schuhgröße**_ an.

	 ![](../../Bilder/artikelfilter/artikelfilter_artikelartikelfilter_maskeFilterauswahlEingerichteteInternerName.png "Zwei Filterauswahlen _**Größe**_ mit internen Namen")

Gehe wie folgt vor:

!!! check "Anlegen von Auswahlwerten"

	 1. klicke die gewünschte Filterauswahl unter _**Filterauswahl (eingerichtete)**_ an
	 2. trage bei Bedarf einen internen Namen ein
	 3. trage den Namen des Auswahlwerts ein, so wie er im Shop angezeigt werden soll
	 4. klicke auf _**Speichern**_.
	 5. wiederhole die Schritte 3 und 4, bis du alle gewünschten Auswahlwerte angelegt hast

![](../../Bilder/artikelfilter/artikelfilter_maskeFilterauswahl_FarbeAusgewaehlt_AuswahlwertHinzufuegen.png "Filterwerte der Filterauswahl _**Farbe**_")

Angelegte Filterwerte werden unter _**Auswahlwerte (eingerichtet)**_ angezeigt.

#### Zuweisen von Auswahlwerten zum Artikel

![](../../Bilder/artikelfilter/artikelfilter_maskeArtikel_Filterauswahl_.png "Bereich _**Filterauswahl**_ in der Artikelmaske")

Um einem Artikel Filterwerte zuzuordnen, bearbeite diesen zunächst unter _**Artikel > Artikel/Kategorien**_. In der Artikelmaske findest du den hierfür vorgesehenen Bereich zwischen den Abschnitten _**Zusatzfelder**_ und _**Google Kategorie**_. 

Auswahlwerte können unabhängig oder abhängig voneinander zugeordnet werden. 

!!! example "Beispiel"

	 ![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_FilterauswahlUnabhaengig.png "Zwei unabhängige Filter-Sets mit Werten aus je einer Filterauswahl")

	 Es befindet sich jeweils nur Filterwerte aus einer Filterauswahl in jedem Filter-Set. Der Artikel kann beim Filtern nach einer beliebigen Kombination der einzelnen Filterwerte aus den jeweiligen Sets gefunden werden.

	 ![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_maskeFilterauswahl.png "Zwei Zusammenstellungen von Artikelauswahlen")

	 Es befinden sich Filterwerte aus mehreren Filterauswahlen in einem Set. Wird nach der _**Farbe**_ _blau_ gefiltert, wird der Artikel nicht gefunden, wenn gleichzeitig nach der _**Größe**_ (Konfektionsgröße) _L_ gefiltert wird, da sich der Filterwert nicht im selben Filter-Set befindet.

##### Zuweisen von unabhängigen Auswahlwerten


!!! check "Zuweisen von unabhängigen Auswahlwerten"
	 1. klicke in der Artikelmaske unter _**Filterauswahl**_ auf _**Hinzufügen**_ ![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_Filterauswahl001_hinzufuegen.png "Dialog _**Hinzufügen**_ enthält bereits Filterauswahlen")
	 2. wenn die gewünschte Filterauswahl noch nicht angezeigt wird, wähle sie aus dem Dropdown _**-- Neuen Filter hinzufügen --**_ aus ![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_Filterauswahl002_neuenFilterHinzufuegen.png "noch nicht angezeigte Filterauswahlen im Dropdown")
	 3. wähle aus einer der Filterauswahlen die gewünschten Filterwerte aus und klicke auf _**Speichern & Schließen**_. ![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_Filterauswahl003_FilterwerteAuswaehlen.png "Filterwerte in der neuen Filterauswahl ausgewählt")
	 4. wiederhole die Schritte 1 bis 3 für alle weiteren Filterwerte aus anderen FIlterauswahlen.



##### Zuweisen von abhängigen Auswahlwerten


!!! check "Zuweisen von abhängigen Auswahlwerten (Filter-Sets)"
	 1. klicke in der Artikelmaske unter _**Filterauswahl**_ auf _**Hinzufügen**_ ![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_Filterauswahl001_hinzufuegen.png "Dialog _**Hinzufügen**_ enthält bereits Filterauswahlen")

	 2. wenn die gewünschte Filterauswahl noch nicht angezeigt wird, wähle sie aus dem Dropdown _**-- Neuen Filter hinzufügen --**_ aus ![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_Filterauswahl002_neuenFilterHinzufuegen.png "noch nicht angezeigte Filterauswahlen im Dropdown")

	 3. wiederhole Schritt 2, bis alle für den Artikel relevanten Filterauswahlen angezeigt werden

	 4. wähle aus den angezeigten Filterauswahlen die gewünschten Filterwerte aus und klicke auf _**Speichern & Schließen**_. ![](../../Bilder/artikelfilter/artikelfilter_artikelartikel_Filterauswahl004_FilterwerteAbhaengigAuswaehlen.png "Filterwerte aus mehreren Filterauswahlen wurden im selben Filter-Set gewählt")

   

#### Erstellen eines Kategoriefilters

Innerhalb von Kategorien kann festgelegt werden welche Filterauswahlen angezeigt werden sollen. 

![](../../Bilder/artikelfilter/artikelfilter_maskeKategorie_Kategoriefilter.png "Filtereinstellungen in der Kategoriemaske")

Wähle die gewünschte Filterauswahl über das Dropdown aus und klicke auf _**Hinzufügen**_.

![](../../Bilder/artikelfilter/artikelfilter_maskeKategorie_KategoriefilterAusgewaehlt.png "Einstellen der Filterauswahl über das Dropdown")

![](../../Bilder/artikelfilter/artikelfilter_maskeKategorie_KategoriefilterHinzugefuegt.png "Filterauswahlen hinzugefügt")

Die Filterauswahlen sind standardmäßig UND-verknüpft. D.h. es werden nur Artikel angezeigt, die die eingestellten Auswahlwerte aus allen Filterauswahlen enthalten. Um dies auf ODER zu ändern, sodass Artikel auch angezeigt werden, wenn diese nur einen der Auswahlwerte enthalten, entferne die jeweiligen Haken unter _**AND**_.

!!! example "Beispiel"
	 Ein Kunde stellt im Filter die Größe _**XL**_ und die Farbe _**rot**_ ein. Sind die Haken für _**AND**_ gesetzt, werden nur Artikel angezeigt, denen gleichzeitig die Auswahlwerte _**XL**_ und _**rot**_ zugeorndet sind. Sind die Haken nicht gesetzt, werden alle Artikel der Größe _**XL**_ angezeigt, auch wenn sie andere Farben als _**rot**_ haben. Gleichzeitig werden alle roten Artikel angezeigt, auch wenn sie andere Größen als _**XL**_ haben.


Setze den Haken für _**Kategorie-Filter anzeigen**_, damit der eingestellte Filter innerhalb der Kategorie verwendet wird.
	 

#### Einstellen des Startseitenfilters

![](../../Bilder/artikelfilter/artikelfilter_StartseitenFilter01.png "Bereich _**Filterauswahl Startseite**_ unter _**Artikel > Artikel-Filter**_")

Für die Startseite des Shops kann ebenfalls ein Artikel-Filter eingestellt werden. 

![](../../Bilder/artikelfilter/artikelfilter_StartseitenFilter02.png "Hinzufügen der Filterauswahl über das Dropdown")

Die Filterauswahl kann über das Dropdown ausgewählt und mit der Schaltfläche _**Hinzufügen**_ dem Startseitenfilter angefügt werden.

![](../../Bilder/artikelfilter/artikelfilter_StartseitenFilter03.png "Filterauswahl _**Farbe**_ hinzugefügt und _**Größe**_ für das Hinzufügen ausgewählt")

Wie beim Kategoriefilter sind die einzelnen Filterauswahlen UND-verknüpft, solange die Haken für _**AND**_ gesetzt sind.

![](../../Bilder/artikelfilter/artikelfilter_StartseitenFilter04.png "Beide Filterauswahlen sind UND-verknüpft")



Über die Einstellung _**Globaler Startseitenfilter**_ wird der Filter auch auf anderen Seiten verwendet, auf denen kein eigener Filter aktiviert ist. Wird zusätzlich der Haken _**Persistenter Startseitenfilter**_ gesetzt, werden die Filter-Einstellungen des Startseitenfilters beim Seitenwechsel weitestmöglich übernommen.

!!! danger "Achtung"

	 Das Deaktivieren des globalen Startseitenfilters schaltet nicht gleichzeitig den persistenten Startseitenfilter ab. Ist der Haken für _**Persistenter Startseitenfilter**_ gesetzt, kann dies auch ohne aktivierten Startseitenfilter Auswirkungen auf die Filter des Shops haben.