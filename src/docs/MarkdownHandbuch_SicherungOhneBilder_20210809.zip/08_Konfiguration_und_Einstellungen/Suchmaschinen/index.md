# Suchmaschinen

Dieses Kapitel beschreibt die in das Shopsystem integrierten Methoden zur Suchmaschinenoptimierung \(SEO, Search Engine Optimization\). Beachte, dass die Konfiguration deines Shops nach diesen Methoden kein besseres Suchmaschinen-Ranking und keinen höheren Absatz garantieren kann. Für ausführliche Informationen zu Meta-Angaben und Shop-Vermarktung, wende dich an eine SEO-Agentur.




