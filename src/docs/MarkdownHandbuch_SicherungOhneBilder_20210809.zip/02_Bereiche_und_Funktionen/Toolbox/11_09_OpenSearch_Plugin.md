# OpenSearch Plugin

Mit dem OpenSearch Plugin kann dem Suchfeld im Internet Explorer und Firefox die Shopsuche als Suchmaschine hinzugefügt werden. Unter _**Toolbox \> OpenSearch Plugin**_ kann das Modul konfiguriert werden. Hier kannst du auswählen, wo der Installationslink erscheinen soll. Setze hierzu die Haken in die entsprechenden Boxen.

Im Reiter _**OpenSearch Konfiguration**_ können die Texte in den Suchen frei festgelegt werden. Hierzu zählen

-   Text für die Menübox _**Suche**_
-   Text für die _**erweiterte Suche**_
-   Kurztext für das Such-Plugin
-   Titel für das Such-Plugin
-   Schlüsselwörter für das Such-Plugin
-   Kontakt E-Mail für das Such-Plugin
-   Beschreibung für das Such-Plugin

Bestätige die gemachten Eingaben mit einem Klick auf _**Speichern**_.

In der Box _**Erweiterte Suche**_ kann über den Link _**Browser-Schnellsuche**_ die Shopsuche zu den eingetragenen Suchmaschinen im Browser hinzugefügt werden.

