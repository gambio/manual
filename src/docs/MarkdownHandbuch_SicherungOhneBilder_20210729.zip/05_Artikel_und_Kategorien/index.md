# Artikel & Kategorien

Auf den folgenden Seiten findest du Anleitungen zum Einstellen und Bearbeiten von Artikeln und Kategorien. Zur allgemeinen Konfiguration deines Shopsystems beachte bitte auch die Kapitel _**Konfiguration**_ und _**Module**_. Die Artikel-Einstellungen findest du, soweit nicht anders angegeben, im Gambio Admin unter dem Menüpunkt _**Artikel**_.




