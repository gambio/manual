# Darstellung / Inhalte

Unter _**Inhalte**_ befinden sich Einstellungen, mit deren Hilfe der Shop gestaltet werden kann, wie _**StyleEdit**_,  _**Template-Einstellungen**_ und _**Teaser-Slider**_. Zudem kann über den _**Content Manager**_ auf Inhaltsseiten und deren Bestandteile zugegriffen sowie eigene Seiten angelegt werden. 


