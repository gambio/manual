# Kunden-Bestellstatistik

Unter _**Statistiken \> Kunden-Bestellstatistik**_ werden die Kunden mit den höchsten Umsätzen aufgeführt. Für die angezeigten Angaben sind keine Filtereinstellungen vorhanden.

!!! note "Hinweis" 
	 Diese Auflistung listet die Kunden rein nach dem Warenwert auf. Bei Kunden mit Bruttorechnung ist dies der Brutto-Warenwert, bei Kunden ohne Steuerberechnung wie Händlern ist dies der Netto-Warenwert. Versandkosten und eventuell zusätzlich erhobene Beträge werden nicht berücksichtigt.

