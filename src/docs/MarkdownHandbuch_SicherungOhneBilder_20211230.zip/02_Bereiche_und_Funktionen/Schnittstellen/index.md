# Schnittstellen

Verschiedene Module von Drittanbietern können zusätzliche Konfigurationen unter _**Module \> Modul-Center**_ voraussetzen. Nähere Informationen zu Schnittstellen von Drittanbietermodulen erhältst du direkt beim jeweiligen Anbieter.

