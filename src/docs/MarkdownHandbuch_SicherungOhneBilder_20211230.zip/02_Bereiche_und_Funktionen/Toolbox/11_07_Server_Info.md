# Server Info

!!! note "Hinweis"

	 Dieser Bereich des Gambio Admins ist nur in selbstgehosteten Shops verfügbar.

Informationen zum Server, auf dem dein Shop installiert ist, kannst du unter _**Toolbox \> Server Info**_ einsehen. Hier werden neben der Shop- und PHP-Version serverspezifische Details und der Inhalt wichtiger Server-Variablen aufgelistet. Aufbau und Ausstattung der für Gambio Webshops verwendeten Server können sehr stark voneinander abweichen.

Du hast die Möglichkeit, uns bei der Weiterentwicklung unserer Shop-Software zu unterstützen, indem du Informationen über deinen Server an uns weiterleitest. Klicke hierzu auf die Schaltfläche _**Senden**_. Das Mitwirken ist absolut freiwillig, die Daten werden dahingehend ausgewertet, auf welcher Art Server-Umgebung Gambio-Shops eingesetzt werden können.

!!! note "Hinweis" 
	 Mit Klick auf _**Senden**_ werden ausschließlich die im angezeigten Formular stehenden Daten einmalig an die Gambio GmbH gesendet.



