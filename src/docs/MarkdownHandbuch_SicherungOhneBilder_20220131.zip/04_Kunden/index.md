# Kunden

Deine Kunden legen in der Grundkonfiguration selbständig ein Kundenkonto in deinem Shop an. Wie du die Anmeldung steuern kannst, liest du im Kapitel _**Kundenregistrierung**_. Wie du Kundenkonten im Gambio Admin anlegst, liest du im Kapitel _**Kundenkonto manuell anlegen**_.




