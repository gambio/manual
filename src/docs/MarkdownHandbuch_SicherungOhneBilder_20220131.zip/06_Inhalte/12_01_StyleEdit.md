# StyleEdit

!!! danger "Achtung"

	 Dieses Kapitel bezog sich auf die Bearbeitung des _**EyeCandy**_-Templates. Dieses Template wird ab Version _**3.4**_ **nicht mehr ausgeliefert** und ist mit aktuellen Shopversionen **nicht kompatibel**.



